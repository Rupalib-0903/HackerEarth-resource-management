const lecturerModel = require('../Models/Lecturer')

const createLecturer = async (req, res) => {
    const lecturerdata = req.body;
    try {
        const newLecturer = new lecturerModel({
            lecturerName: lecturerdata.lecturerName,
            leacturerEmail: lecturerdata.leacturerEmail,
        });

        // Save the new lecturer to the database
        const savedLecturer = await newLecturer.save();

       
        res.status(201).json(newLecturer);
    } catch (error) {
        console.log(error)
        res.status(400).json({ error: error.message });
    }
};

module.exports = {createLecturer}