const mongoose = require('mongoose');
const timetableModel = require('../Models/TimeTable'); 

const createTimeTable = async (req, res) => {
    const timeTabledata = req.body;
    const subjectId = req.params.subjectId;

    try {
        // Validate time for each day
        const days = Object.keys(timeTabledata);
        console.log(days)
        for (let day of days) {
            const slots = timeTabledata[day];
           
            for (let slot of slots) {
                if (slot.EndTime <= slot.StartTime) {
                    return res.status(400).json({
                        error: `End time must be greater than start time for ${day}: ${slot.StartTime} and ${slot.EndTime}`
                    });
                }
                if (slot.StartTime <= '07:00') {
                    return res.status(400).json({
                        error: `End time cannot exceed 7:00 am for ${day}: ${slot.StartTime}`
                    });
                }
                if (slot.EndTime >= '20:01') {
                    return res.status(400).json({
                        error: `End time cannot exceed 18:00 pm for ${day}: ${slot.EndTime}`
                    });
                }
                slot.SubjectId = subjectId; 
            }
          
            
            slots.sort((a, b) => {
                return a.StartTime.localeCompare(b.StartTime);
            });

            console.log(slots)
            // Checking for overlaps
            for (let i = 0; i < slots.length - 1; i++) {
                const currentSlot = slots[i];
                const nextSlot = slots[i + 1];

                // Convert times to minutes for comparing 
                const endTimeCurrent = convertTimeToMinutes(currentSlot.EndTime);
                const startTimeNext = convertTimeToMinutes(nextSlot.StartTime);

                if (startTimeNext <= endTimeCurrent) {
                    return res.status(400).json({
                        error: `Time overlap detected for ${day}: ${currentSlot.StartTime} - ${currentSlot.EndTime}  and ${nextSlot.StartTime} -${nextSlot.EndTime}`
                    });
                }
            }
        }

        // If no overlaps, proceed to save the timetable
        const newTimeTable = new timetableModel(timeTabledata);
        await newTimeTable.save();
        
       
        res.status(201).json(newTimeTable);
    } catch (error) {
        console.error(error);
        res.status(400).json({ error: error.message });
    }
};

// Helper function to convert time string (HH:MM) to minutes since midnight
function convertTimeToMinutes(timeString) {
    const [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes;
}


module.exports = {
    createTimeTable
};
