const subjectModel = require('../Models/Subject')

const createSubject = async (req, res) => {
    const subjectdata = req.body;
    try {
        const newSubject = new subjectModel({
            name: subjectdata.name,
            code: subjectdata.code,
        });

        // Save the new lecturer to the database
        const savedSubject = await newSubject.save();

       
        res.status(201).json(newSubject);
    } catch (error) {
        console.log(error)
        res.status(400).json({ error: error.message });
    }
};

module.exports = {createSubject}