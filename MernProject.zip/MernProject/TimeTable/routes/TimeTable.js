const express = require('express');
const router = express.Router();
const timeTableController = require('../controllers/timeTable')


router.post('/:subjectId',timeTableController.createTimeTable)

module.exports = router;