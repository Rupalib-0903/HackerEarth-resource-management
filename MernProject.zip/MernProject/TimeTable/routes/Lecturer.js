const express = require('express');
const router = express.Router();
const lecturerController = require('../controllers/lecturer')


router.post('/',lecturerController.createLecturer)

module.exports = router;