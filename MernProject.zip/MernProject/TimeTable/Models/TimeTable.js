const mongoose = require('mongoose');


const timeValidator = {
    validator: function(value) {
        // Regular expression to match "HH:MM" format
        return /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(value);
    },
    message: props => `${props.value} is not a valid time format!`
};

const scheduleSchema = new mongoose.Schema({
    SubjectId: {
        type: String,
        required: [false, 'SubjectId is required.']
    },
    StartTime: {
        type: String,
        required: [true, 'StartTime is required.'],
        validate: timeValidator
    },
    EndTime: {
        type: String,
        required: [true, 'EndTime is required.'],
        validate: timeValidator
    }
});
const timeTableSchema = new mongoose.Schema({
    Monday: {
        type: [scheduleSchema],
        required: false
    },
    Tuesday: {
        type: [scheduleSchema],
        required: false
    },
    Wednesday: {
        type: [scheduleSchema],
        required: false
    },
    Thursday: {
        type: [scheduleSchema],
        required: false
    },
    Friday: {
        type: [scheduleSchema],
        required: false
    },
    Saturday: {
        type: [scheduleSchema],
        required: false
    },
    Sunday: {
        type: [scheduleSchema],
        required: false
    }
}, { timestamps: true });

const TimetableModel = mongoose.model('Timetable', timeTableSchema);

module.exports = TimetableModel;
