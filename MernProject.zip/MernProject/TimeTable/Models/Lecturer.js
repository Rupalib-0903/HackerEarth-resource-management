const mongoose = require('mongoose');

const lecturerSchema = mongoose.Schema({
   
    lecturerName: {
        type: String,
        required: [true, 'lecturerName is required.']
    },
    SubjectId: {
        type: [{ type : mongoose.Schema.Types.ObjectId, ref : "subject"}]
    },
    leacturerEmail : {
        type: String,
        required: [true, 'Email is required.'],
        unique: true,
    }
},{timestamps:true});

const lecturerModel = mongoose.model("lecturer", lecturerSchema);

module.exports = lecturerModel;