const mongoose = require('mongoose');

const subjectSchema = mongoose.Schema({
   
    name: {
        type: String,
        required: [true, 'name is required.']
    },
    code: {
        type: String,
        required: [true, 'code is required.']
    },
    LecturerId: {
        type: [{ type : mongoose.Schema.Types.ObjectId, ref : "lecturer"}]
    }
},{timestamps:true});

const subjectModel = mongoose.model("subject", subjectSchema);

module.exports = subjectModel;