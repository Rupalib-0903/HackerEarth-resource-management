require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGODB_URL)
.then(() => {
    console.log('Database connected successfully!');
})
.catch((error) => {
    console.log('Error while connecting database!')
})

//router
const lecturerRoutes = require('./routes/Lecturer');
const subjectRoutes = require('./routes/Subject');
const timeTableRoutes = require('./routes/TimeTable');

//use routes
app.use('/lecturer',lecturerRoutes)
app.use('/subject',subjectRoutes)
app.use('/timetable',timeTableRoutes)

app.listen(process.env.PORT, () => {
    console.log(`Server created and running on http://localhost:${process.env.PORT}/`);
})

